/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodos;

import javax.swing.JOptionPane;

/**
 *
 * @author Ruben
 */
public class probador {
            
    public static void main(String args[]){
        mVentas miData=null;
        int op;
        
        do{
            op=Integer.parseInt(JOptionPane.showInputDialog(
            "Menú Principal \n"+
            "1. Crear y cargar matriz de ventas. \n"+
            "2. Mostrar ventas. \n"+
            "3. Salir. \n"+
            "Entre su opción: ?"        
            ));
            
            switch(op){
                case 1:
                    miData = new mVentas();
                    miData.setLlenar();
                break;
                case 2:
                    if(miData==null)
                        JOptionPane.showMessageDialog(null, 
                        "La matriz no tiene registrado los datos!!");
                    else
                        miData.getMostrarV();
                break;
                case 3:                    
                    JOptionPane.showMessageDialog(null, 
                    "Adios!!!");
                break;
                default:
                    JOptionPane.showMessageDialog(null, 
                    "Error!: Opción invalida, intente"
                    + " nuevamente.");                                    
            }
            
        }while(op!=3);
        
        System.exit(0);
    }
}
